var Todays  = new Date();

document.getElementById("date1").innerHTML =  Todays.toDateString();

document.getElementById("date2").innerHTML =  Todays.toDateString();
document.getElementById("date3").innerHTML =  Todays.toDateString();
